#`/scripts/`

## `analyze_endpoints_and_create_files.py`

This is a script to analyze all endpoints and create the .py files, endpoint documentation, and parameter documentation. Please note that this file might break dependent on major changes to the NBA API.

It will be beneficial to enable `DEBUG` and `DEBUG_STORAGE` to help in the debugging process.
